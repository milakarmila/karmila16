-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 16 Apr 2019 pada 18.07
-- Versi Server: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugas_pw_183040012`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `film`
--

CREATE TABLE `film` (
  `no` int(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `judul` varchar(128) NOT NULL,
  `sutradara` text NOT NULL,
  `pemain` varchar(150) NOT NULL,
  `jenis` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `film`
--

INSERT INTO `film` (`no`, `img`, `judul`, `sutradara`, `pemain`, `jenis`) VALUES
(30, '1.jpg', 'Dillan', 'isdb', 'idb', 'jhbd'),
(33, '1.jpg', 'Dillan 1991', 'Fajar Bustomi dan Pidi Baiq"', 'Iqbaal Ramadhan, Vanesha Prescilla dan Jerome Kurnia', 'Romance'),
(34, '2.jpg', 'Captain Marvel', 'Derby Romero', 'Cinta Laura Kiehl, Jovarel Callum, Irsyadillah, Fatih Unru, Basmalah Gralind, Juliant Rafael, Gesata Stella, Yayu Unru, Elsa Diandra, Chico Radellaa.', 'Horror'),
(35, '2.jpg', 'Captain Marvel', 'Anna Boden Ryan Fleck', 'Brie Larson dan Samuel L. Jackson', 'Action'),
(36, '4.jpg', 'FIVE FEET APART', 'Justin Baldoni', 'Cole Sprouse, Haley Lu Richardson, Claire Forlani, Parminder Nagra, Moises Arias, Emily Baldo', 'Drama, Romance'),
(37, '5.jpg', 'POHON TERKENAL', 'Monty Tiwa, Annisa Meutia', 'Umay Shahab, Laura Theux, Raim La Ode, Cok Simbara, Ajis Doa Ibu', 'Drama, Comedy'),
(38, '6.jpg', 'MY STUPID BOSS 2', 'Upi Avianto', 'Reza Rahadian, Bunga Citra Lestari, Chew Kinwah, Ledil Putra, Atikah Suhaemi, Zulkarnaen, Oey, Alex Abbad, Melissa Karim, Solaiman, Sahil Shah', 'Komedi'),
(39, '7.jpg', 'DUMBO2', 'Fajar Bustomi dan Pidi Baiq', 'Colin Farrell, Michael Keaton, Danny Devito, Eva Green, Alan Arkin, Finley Hobbins, Nico Parker', 'Family, Fantasy'),
(40, '8.jpg', 'ALL THE DEVIL’S MEN', 'Matthew Hope', 'Milo Gibson, Sylvia Hoeks, Gbenga Akinnagbe, Joseph Millson, Elliot Cowan, William Fichtner', 'Action'),
(41, '9.jpg', 'Film Foxtrot Six (2019)', 'Randy Korompis', 'Verdi Solaiman, Chicco Jerikho, Rio Dewanto, Arifin Putra, Mike Lewis, Miller Khan, Edward Akbar, Julie Estelle, Norman R. Akyuwen, Cok Simbara', 'Action'),
(42, '10.jpg', 'Film Happy Death Day 2U (2019)', 'Christopher Landon', 'Jessica Rothe, Ruby Modine, Israel Broussard', 'Horror, Mystery, Thriller'),
(43, '10.jpg', 'Matahari', 'Jurnalis', 'Senia', 'romantis');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `film`
--
ALTER TABLE `film`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
