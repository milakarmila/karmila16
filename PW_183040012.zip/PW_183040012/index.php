<!DOCTYPE html>
<html>
	<head>
		<title> </title>
	</head>
	<body>
	<thead>
				<tr>
<center>					
<table border="1" width="400">
			
		<h1>
			<tr bgcolor="Deepskyblue">
			<th width="165" height="100">Nama 	: Mila Karmila</td>
		 	<th width="165" height="100">NPM	: 183040012</th>
		</tr>
		<th colspan="5" bgcolor="aqua">
		<br>
		LATIHAN 5
		<br>
		<br>
		</tr></th>
		<th colspan="5" bgcolor="aqua">
		<li><a href="pertemuan5/latihan/latihan5a.php">Latihan5a</a></li><br>
		<li><a href="pertemuan5/latihan/latihan5b.php">Latihan5b & Latihan5c </a></li><br>
		<li><a href="pertemuan5/latihan/latihan5d.php">Latihan5d</a></li><br>
		<li><a href="pertemuan5/latihan/latihan5e/login.php">Latihan5e</a></li><br>
		</tr></th>
		<th colspan="5" bgcolor="aqua">
		<br>
		LATIHAN 6
		<br>
		<br>
		</tr></th>
		<th colspan="5" bgcolor="aqua">
		<li><a href="pertemuan6/latihan6a/latihan6a.php">Latihan6a</a></li><br>
		<li><a href="pertemuan6/latihan6b/latihan6b.php">Latihan6b</a></li><br>
		<li><a href="pertemuan6/latihan6c/index.php">Latihan6c</a></li><br>
		</tr></th>
		<th colspan="5" bgcolor="aqua">
		<br>
		LATIHAN 7
		<br>
		<br>
		</tr></th>
		<th colspan="5" bgcolor="aqua">
		<li><a href="pertemuan7/latihan7a/index.php">Latihan7a</a></li><br>
		<li><a href="pertemuan7/latihan7b/index.php">Latihan7b</a></li><br>
		<li><a href="pertemuan7/latihan7c/index.php">Latihan7c</a></li><br>
		<li><a href="pertemuan7/latihan7d/index.php">Latihan7d</a></li><br>
		<li><a href="pertemuan7/latihan7e/index.php">Latihan7e</a></li><br>	
		</tr></th>
		<th colspan="5" bgcolor="aqua">
		<br>
		<a href="pertemuan7/tugas3/index.php">TUGAS 3</a><br>
		<br>
		</tr></th>
	</h1>

	</thead>
</table>
</center>
	</body>
</html>