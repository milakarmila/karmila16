<!DOCTYPE html>
<html lang="en">
<head>
    <title>latihan 5a</title>
    <style>
    .kotak 
    {
        color: black;
        width: 30px;
        height: 30px;
        border: 1px solid;
        display: inline-block;
        line-height: 30px;
        text-align: center;
        margin : 2px;
    }

    .aqua {
        background-color: aqua;
    }

    .clear
    {
        clear: both;
    }
    </style>
</head>
<body>
<?php
 if(isset($_GET['angka'])){
     $angka = $_GET['angka'];
     for ($i = $angka; $i >=1 ; $i--){
         for($j=1; $j <= $i; $j++){
             if($i %2 == 0){
                 echo "<div class='kotak aqua'>$i</div>";
             }
             else {
                echo "<div class='kotak'>$i</div>";
             }
         }
         echo"<br>";
     }
 }

?>
</body>
</html>