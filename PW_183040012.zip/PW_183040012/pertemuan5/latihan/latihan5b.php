<?php 
$a  =[
[
	"no" => "1",
	"img" => "1.jpg",
	"judul" => "Dillan 1991",
	"sutradara" => "Fajar Bustomi dan Pidi Baiq",
	"pemain" => "Iqbaal Ramadhan, Vanesha Prescilla dan Jerome Kurnia",
	"tanggalrilis" => "24 Februari 2019 (Bandung) 28 Februari 2019",
	"jenisfilm" => "Romance"
],
[
	"no" => "2",
	"img" => "../img/2.jpg",
	"judul" => "Captain Marvel",
	"sutradara" => "Anna Boden Ryan Fleck",
	"pemain" => "Brie Larson dan Samuel L. Jackson",
	"tanggalrilis" => "27 February - 8 March 2019",
	"jenisfilm" => "Action"
],
[
	"no" => "3",
	"img" => "../img/3.jpg",
	"judul" => "Mati Anak",
	"sutradara" => "Derby Romero",
	"pemain" => "Cinta Laura Kiehl, Jovarel Callum, Irsyadillah, Fatih Unru, Basmalah Gralind, Juliant Rafael, Gesata Stella, Yayu Unru, Elsa Diandra, Chico Radellaa.",
	"tanggalrilis" => "28 Maret 2019",
	"jenisfilm" => "Horror"
],
[
	"no" => "4",
	"img" => "../img/4.jpg",
	"judul" => "FIVE FEET APART",
	"sutradara" => "Justin Baldoni",
	"pemain" => "Cole Sprouse, Haley Lu Richardson, Claire Forlani, Parminder Nagra, Moises Arias, Emily Baldo",
	"tanggalrilis" => "22 Maret 2019",
	"jenisfilm" => "Drama, Romance"
],
[
	"no" => "5",
	"img" => "../img/5.jpg",
	"judul" => "POHON TERKENAL",
	"sutradara" => "Monty Tiwa, Annisa Meutia",
	"pemain" => "Umay Shahab, Laura Theux, Raim La Ode, Cok Simbara, Ajis Doa Ibu",
	"tanggalrilis" => "21 Maret 2019",
	"jenisfilm" => "Drama, Comedy"
],
[
	"no" => "6",
	"img" => "../img/6.jpg",
	"judul" => "MY STUPID BOSS 2",
	"sutradara" => "Upi Avianto",
	"pemain" => "Reza Rahadian, Bunga Citra Lestari, Chew Kinwah, Ledil Putra, Atikah Suhaemi, Zulkarnaen, Oey, Alex Abbad, Melissa Karim, Solaiman, Sahil Shah",
	"tanggalrilis" => "28 Maret 2019",
	"jenisfilm" => "Komedi"
],
[
	"no" => "7",
	"img" => "../img/7.jpg",
	"judul" => "DUMBO2",
	"sutradara" => "Fajar Bustomi dan Pidi Baiq",
	"pemain" => "Colin Farrell, Michael Keaton, Danny Devito, Eva Green, Alan Arkin, Finley Hobbins, Nico Parker",
	"tanggalrilis" => " 28 Maret 2019",
	"jenisfilm" => "Family, Fantasy"
],
[
	"no" => "8",
	"img" => "../img/8.jpg",
	"judul" => "ALL THE DEVIL’S MEN",
	"sutradara" => "Matthew Hope",
	"pemain" => "Milo Gibson, Sylvia Hoeks, Gbenga Akinnagbe, Joseph Millson, Elliot Cowan, William Fichtner",
	"tanggalrilis" => "24 Februari 2019 (Bandung) 28 Februari 2019",
	"jenisfilm" => "Action"
],
[
	"no" => "9",
	"img" => "../img/9.jpg",
	"judul" => "Film Foxtrot Six (2019)",
	"sutradara" => "Randy Korompis",
	"pemain" => "Verdi Solaiman, Chicco Jerikho, Rio Dewanto, Arifin Putra, Mike Lewis, Miller Khan, Edward Akbar, Julie Estelle, Norman R. Akyuwen, Cok Simbara",
	"tanggalrilis" => "21 Februari 2019",
	"jenisfilm" => "Action"
],
[
	"no" => "10",
	"img" => "../img/10.jpg",
	"judul" => "Film Happy Death Day 2U (2019)",
	"sutradara" => "Christopher Landon",
	"pemain" => "Jessica Rothe, Ruby Modine, Israel Broussard",
	"tanggalrilis" => "13 Februari 2019",
	"jenisfilm" => "Horror, Mystery, Thriller"
]
];
?>
<!DOCTYPE html>
<html>
<head>
	<title>laihan 4d</title>
	<style>
		.radial_circle{
			 background:orange;
    		 background:-webkit-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
   		     background:-moz-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
  		     background:-o-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
    		 filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0, finishopacity=100, style=2);height:100px;
		}
		.dm{
			text-decoration: none;
			color: black;

		}
		.contener{
			background-color: Sandybrown ;
			width: 400px;
			height: 500px;
			margin: auto;
			font-family: cursive;
			font-size: 15px;
			padding: 10px; 
			box-shadow: 5px 5px 15px 5px #000000;
		}
		.text{
			color:#FFE9C7; 
			background:#FF6C17;  
			text-shadow: 2px 2px 2px #A6250C;
			text-align: center;
		}
	</style>
</head>
<body class="radial_circle">
	
	<div class="contener">
		<h3 class="text">Selamat Datang di Film terbaru<br>2019</h3>
	<ul>
		<?php foreach ($a as $kate):  ?>
		<tr align="center">
			<a class="dm" href="latihan5c.php?no= <?= $kate['no']; ?>&img= <?= $kate['img']; ?>&judul= <?= $kate['judul'];?>&sutradara= <?= $kate['sutradara']; ?>&pemain= <?= $kate['pemain']; ?>&tanggalrilis= <?= $kate['tanggalrilis']; ?>&jenisfilm= <?= $kate['jenisfilm']; ?>"><?= $kate['judul']; ?>"</a><br><br>
		<?php endforeach; ?>
		<tr>
			</ul>
	</div>

</body>
</html>