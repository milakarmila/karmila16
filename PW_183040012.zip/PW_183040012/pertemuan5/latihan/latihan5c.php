<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>laihan 5c</title>
	<style>
		.am {
			color: red;  
			text-shadow: 0 0 4px #ccc, 0 -5px 4px #ff4, 2px -10px 6px #fd3, -2px -15px 11px #f80, 2px -18px 18px #f20;
		}
		.a{
			text-decoration: none;
		}
	</style>
</head>
<body bgcolor="black">

		<h1 class="am" align="center">KUMPULAN FILM-FILM TERBARU 2019</h1>
		<form method="post">
		<button><h4 align="left"><a class="a" href="./latihan5b.php">Kembali</a></h4></button>
		</form><br>

	<table align="center" border="1" cellpadding="4" cellspacing="0" bgcolor="Sandybrown">
		<tr align="center" height="50">
			<td>No</td>
			<td>Gambar</td>
			<td>Judul</td>
			<td width="200">Sutradara</td>
			<td width="300">Pemain</td>
			<td>Tanggal Riris</td>
			<td>Jenis Film</td>
		</tr>
		

		<tr align="center">
			<td align="center"><?= $_GET["no"]?></td>
			<td><img src="<?= $_GET['img']; ?>" alt ="img"></td>
   
   			 <td><?= $_GET['judul']; ?></td>
   			 <td><?= $_GET['sutradara']; ?></td>
      		 <td><?= $_GET['pemain']; ?></td>
   			 <td><?= $_GET['tanggalrilis']; ?></td>
    		 <td><?= $_GET['jenisfilm']; ?></td>
    
    </tr>
    </table>
	</center>

</body>
</html>