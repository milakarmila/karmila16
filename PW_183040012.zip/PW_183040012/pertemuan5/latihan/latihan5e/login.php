<?php 
if(isset($_POST['submit'])){
    if($_POST['username'] == 'mila' && $_POST ['password'] == '123'){
        header("location: admin.php");
        exit;
    }else {
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
</head>
<body>
    <h3>Halaman Login</h3>
    <?php if(isset($error)): ?>
    <p style="color:salmon; font-style: italic;">Maaf, Username dan Password salah!</p>
    <?php endif ?>
    <table>
        <form action="" method="post">
        <tr>
        <td>
            <label>Username</label>
        </td>
        <td>
        <input type="text" name="username">
        </td>
        </tr>
        <tr>
        <td>
            <label>Password</label>
        </td>
        <td>
            <input type="password" name="password">
        </td>
        </tr>
        <tr>
        <td>
            <button type="submit" name="submit">Masuk</button>
        </td>
        </tr>
        </form>



    </table>
</body>
</html>