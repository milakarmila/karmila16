<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin</title>
    <style>
    .div {
        margin: 100px 10px 100px 450px;
        text-align: center ;
        border: 1px solid black;
        background-color: Sandybrown;
        width:300px;
        height: 100px;
        color: salmon;
        box-shadow: 20px 20px 50px black;
        font-family: arial;
    }
    </style>
</head>
<body>
    <div>
<h3>Selamat Datang Admin</h3>
<button type="submit"><a href="login.php">Logout</a></button>
    </div>
</body>
</html>