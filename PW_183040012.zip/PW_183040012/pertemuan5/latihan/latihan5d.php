<!DOCTYPE html>
<html lang="en">
<head>
    <title>latihan 5d</title>
    <style>
    .kotak 
    {
        width: 30px;
        height: 30px;
        border: 1px solid;
        display: inline-block;
        line-height: 30px;
        text-align: center;
        margin : 2px;
        color: black;
    }

    .aqua {
        background-color: aqua;
    }

    .clear
    {
        clear: both;
    }
    </style>
</head>
<body>

<form method="post">
    <label> Masukan Angka : </label>
    <input type="text" name ="angka">
    <button type="submit">submit</button>
</form>
<br>
<?php
 if(isset($_POST['angka'])){
     $angka = $_POST['angka'];
     for ($i = $angka; $i >=1 ; $i--){
         for($j=1; $j <= $i; $j++){
             if($i %2 == 0){
                 echo "<div class='kotak aqua'>$i</div>";
             }
             else {
                echo "<div class='kotak'>$i</div>";
             }
         }
         echo"<br>";
     }
 }

?>
</body>
</html>