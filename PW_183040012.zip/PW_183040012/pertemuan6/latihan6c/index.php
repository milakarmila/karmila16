<?php 
require 'function.php';
$film = query("SELECT * FROM film");
?>

<html>
    <head>
        <title>latihan 6c</title>
    </head>
         <style>
        body{
            color: black;
        }
        h2{
            text-align: center;
        }
        tr{
            text-align: center;
            height: 50px;
        }
        .dm{
            text-decoration: none;
            color: black;
        }
        .contener{
            background-color: Sandybrown ;
            width: 400px;
            height: 500px;
            margin: auto;
            font-family: cursive;
            font-size: 15px;
            padding: 10px; 
            box-shadow: 5px 5px 15px 5px #000000;
        }
    </style>
    </head>
    <body>
    <div class="contener">
    <h2>Selamat Datang di Film terbaru<br>2019</h2>
    <table align="center" border="1px" cellspacing="0">
    
            <?php foreach ($film as $kate) { ?>
                    <a class="dm" href="profile.php?no=<?=$kate['no'];?>"><?= $kate['judul']?></a>
            <br>    
            <?php } ?>
        
	</div>
    </body>
</html>
