<?php 
require 'function.php';
$film = query("SELECT * FROM film");
?>

<html>
    <head>
        <title>latihan 6b</title>
        <style>
        body{
             background:orange;
             background:-webkit-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             background:-moz-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             background:-o-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0, finishopacity=100, style=2);height:100px;
        }
        h1{
            text-align: center;
        }
        tr{
            text-align: center;
            height: 50px;
        }
    </style>
    </head>
    <body>
    <h1>Selamat Datang di Film terbaru<br>2019</h1>
    <table align="center" border="1px" cellspacing="0">
            <tr>
               <th>No</th>
                <th>Gambar</th>
                <th>Judul</th>
                <th>Sutradara</th>
                <th>Pemain</th>
                <th>jenis Film</th>
            </tr>
            <?php $i = 1; ?>
            <?php foreach ($film as $kate) { ?>
            <tr>
                <td><?= $i++; ?></td>
                <td><img src="img/<?= $kate['img'];?>"></td>
                <td class="judul"><?= $kate['judul'] ?></td>
                <td><?= $kate['sutradara'] ?> </td>
                <td><?= $kate['pemain'] ?> </td>
                <td><?= $kate['jenis'] ?></td>
            </tr>
            <?php } ?>
        </table>
        
    </body>
</html>
