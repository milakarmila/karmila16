<?php 
require 'function.php';
if (isset($_GET['cari'])){
    $keyword = $_GET['a'];
    $film = query("SELECT * FROM film WHERE
        judul LIKE '%$keyword%' OR
        sutradara LIKE '%$keyword%' OR
        pemain LIKE '%$keyword%' OR
        jenis LIKE '%$keyword%' ");
} else {
    $film = query("SELECT * FROM film");
}

 ?>


 <!DOCTYPE html>
 <html>
 <head>
    <title>halaman admin</title>
    <style>
        tr{
            text-align: center;
        }
    </style>
 </head>
 <body>

    <form action="" method="get">
        <input type="text" name="a" id="a" class="form-control" placeholder="Search...">
        <button type="submit" name="cari" id="cari">Cari</button><br><br><button><a href="tambah.php">Tambah Data</a></button><br><br>
    </form>
    <table border="1px" cellspacing="0">

            <tr>
                <th>No</th>
                <th>Gambar</th>
                <th>Judul</th>
                <th width="250">Sutradara</th>
                <th>Pemain</th>
                <th width="150">Jenis Film</th>
                <th width="100">Alat</th>
            </tr>
        <?php if(empty($film)) : ?>
            <tr>
                <td colspan="7">
                    <h1 align="center">Data Tidak Ditemukan</h1>
                </td>
            </tr>

            <?php else : ?>
            <?php $i=1; ?>
            <?php foreach ($film as $adm): ?>
                <tr>
                    <td><?= $i++; ?></td>
                    <td><img align ="center" src="../../../assets/img/<?=$adm['img']; ?>"></td>
                    <td class="judul"><?= $adm['judul']; ?></td>
                    <td><?= $adm['sutradara']; ?> </td>
                    <td><?= $adm['pemain']; ?> </td>
                    <td><?= $adm['jenis']; ?></td>
                    <td>
                        <a href="hapus.php?no=<?=$adm['no']?>">Hapus</a> | 
                        <a href="ubah.php?no=<?=$adm['no']?>">Ubah</a>
                    </td>
                </tr>
            <?php endforeach ?>
        <?php endif; ?>
    </table>
     <button><a href="../logout.php">LOGOUT</a></button>
 </body>
 </html>