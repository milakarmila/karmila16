<?php 
session_start();
require'helper/function.php';

if(isset($SESSION['user'])){
    header("location: ../index.php");
    exit;
}

if (isset($_POST['submit'])){
    $username = $_POST['user'];
    $password = $_POST['pass'];
    $cek_user = mysqli_query(koneksi(), "SELECT * FROM user WHERE username = '$username'");
    if (mysqli_num_rows($cek_user) > 0) {
        $row = mysqli_fetch_assoc($cek_user);

        if (password_verify($pass, $row['password'])){

            $SESSION['user'] = $_POST['user'];
            $SESSION['hash'] = hash('sha256', $row['id'], false);

            if (hash('sha256', $row['id']) == $_SESSION['has']){
                header("location: ../index.php");
                die;
            }
            header("location: ../index.php");
        die;
        }
    }
    $error = true;
}

 ?>
<?php 
if(isset($_POST['submit'])){
    if($_POST['username'] == 'admin' && $_POST ['password'] == 'admin'){
        header("location: helper/index.php");
        exit;
    }else {
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <style >
        .contener{
            background-color: Sandybrown ;
            width: 400px;
            height: 200px;
            margin: auto;
            font-family: cursive;
            font-size: 15px;
            padding: 10px; 
            box-shadow: 5px 5px 15px 5px #000000;
            text-align: center;
        }
        h2{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="contener">
    <h3>Halaman Login</h3>
    <?php if(isset($error)): ?>
    <p style="color:salmon; font-style: italic;">Maaf, Username dan Password salah!</p>
    <?php endif ?>
    <table align="center">
        <form action="" method="post">
        <tr>
            <td>
                <label>Username</label>
            </td>
            <td>
                <input type="text" name="username">
            </td>
        </tr>
        <tr>
            <td>
                <label>Password</label>
            </td>
            <td>
            <input type="password" name="password">
            </td>
        </tr>
        <tr>
            <td>
            <button type="submit" name="submit">Masuk</button>
            </td>
        </tr>
        </form>
    </table>
    </div>
</body>
</html>