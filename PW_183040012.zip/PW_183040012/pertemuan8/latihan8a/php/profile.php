<?php   
if(!isset($_GET['no'])){
    header("location: ../index.php");
    exit;
}
require 'helper/function.php';
$no = $_GET['no'];
$kate = query ("SELECT * FROM film WHERE no=$no")[0];

 ?>


<html>
    <head>
        <title>tugas</title>
    </head>
    <style>
        table{
            border : 1px solid black;
            text-align : center;
            font-size : 20px;
        }
        td{
            padding : 15px;
        }
        h3{
            text-align : center;
            font-size : 30px;
        }
        .contener{
            background-color: Sandybrown ;
            width: 400px;
            height: 300px;
            margin: auto;
            font-family: cursive;
            font-size: 15px;
            padding: 10px; 
            box-shadow: 5px 5px 15px 5px #000000;
            text-align: center;
        }
        h2{
            text-align: center;
        }
    </style>
    <body class="container">
        <h3>Kumpulan Film Terbaru<br>2019</h3>
    <table border="1px">
            <tr>
                <th>Gambar</th>
                <th>Judul</th>
                <th>Sutradara</th>
                <th>Pemain</th>
                <th>Jenis Film</th>
            </tr>
            <tr>
                <td><img src="../../assets/img/<?= $kate['img'];?>"></td>
                <td><?= $kate["judul"]; ?></td>
                <td><?= $kate["sutradara"]; ?></td>
                <td><?= $kate["pemain"]; ?></td>
                <td><?= $kate["jenis"]; ?></td>
            </tr>
        </table>
		
    </body>
</html>
