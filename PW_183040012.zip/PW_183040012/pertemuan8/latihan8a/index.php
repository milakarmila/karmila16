<?php 
require 'php/helper/function.php';
$film = query("SELECT * FROM film");
?>

<html>
    <head>
        <title>latihan 6c</title>
    </head>
    <style>
        table{
            border : 1px solid black;
            text-align : center;
            font-size : 20px;
        }
        td{
            padding : 15px;
        }
        h3{
            text-align : center;
            font-size : 30px;
        }
        .container {
            text-align: center;
        }
    </style>
    <body class="container">
        <h3>Judul Film</h3>
            <?php foreach ($film as $kate) { ?>
                    <a href="   php/profile.php? no=<?=$b['no'];    ?>"><?= $kate['judul']    ?></a>
            <br>    
            <?php } ?>
        <br>
        <a href="php/login.php">LOGIN</a>
		
    </body>
</html>
