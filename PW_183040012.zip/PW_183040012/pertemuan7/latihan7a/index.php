<?php 
require 'function.php';
$film = query("SELECT * FROM film");
//var_dump($film);

 ?>


 <html>
    <head>
        <title>latihan7a</title>
         <style>
        body{
             background:orange;
             background:-webkit-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             background:-moz-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             background:-o-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0, finishopacity=100, style=2);height:100px;
        }
        h1{
            text-align: center;
        }
        tr{
            text-align: center;
            height: 50px;
        }
        .bt{ text-decoration: none;
            color: black;
        }
    </style>
    </head>
    <body>
    <h1>Selamat Datang di Film terbaru<br>2019</h1>
    <table align="center" border="1px" cellspacing="0">
 		<thead>
 			<tr>
 				<th>No</th>
                <th>Gambar</th>
                <th>Judul</th>
                <th>Sutradara</th>
                <th>Pemain</th>
                <th>jenis Film</th>
                <th>Alat</th>
 			</tr>
 		</thead>
 		<tbody>
 			<?php $i=1; ?>
 			<?php foreach ($film as $adm): ?>
 				<tr>
 					<td><?= $i++; ?></td>
 					<td><img align ="center" src="img/<?=$adm['img']; ?>"></td>
	             	<td class="judul"><?= $adm['judul']; ?></td>
               	    <td><?= $adm['sutradara']; ?> </td>
                    <td><?= $adm['pemain']; ?> </td>
                    <td><?= $adm['jenis']; ?></td>
                    <td>
 						<button><a class="bt" href="">hapus</a></button> | 
 						<button><a class="bt" href="">ubah</a></button> 
 					</td>
 				</tr>

 			<?php endforeach ?>
 		</tbody>
 	</table>
 </body>
 </html>