<?php 
require 'function.php';
if (isset($_POST['submit'])){
	if (tambah($_POST) > 0) {
		echo "<script>
				alert('Data Berhasil Ditambahkan!');
				document.location.href = 'index.php'
				</script>";
	} else {

		echo "<script>
				alert('Data Gagal Ditambahkan!');
				</script>";

	}
}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
        <title>latihan 7b</title>
         <style>
        body{
            color: black;
        }
        h2{
            text-align: center;
        }
        tr{
            text-align: center;
            height: 50px;
        }
        .dm{
            text-decoration: none;
            color: black;
        }
        .contener{
            background-color: Sandybrown ;
            width: 400px;
            height: 500px;
            margin: auto;
            font-family: cursive;
            font-size: 15px;
            padding: 10px; 
            box-shadow: 5px 5px 15px 5px #000000;
        }
    </style>
    </head>
    <body>
    <div class="contener">
    <h2>Selamat Datang di Film terbaru<br>2019</h2>
 	</style>
 </head>
 <body>
 	<table>
 		<form action="" method="post">
 			<tr>
 				<td>
 					<label for="img">Gambar</label>
 				</td>
 				<td>
 					<input type="text" name="img" id="img">
 				</td>
 			</tr>
 			<tr>
 				<td>
 					<label for="judul">Judul</label>
 				</td>
 				<td>
 					<input type="text" name="judul" id="judul">
 				</td>
 			</tr>
 			<tr>
 				<td>
 					<label for="sutradara">Sutradara</label>
 				</td>
 				<td>
 					<input type="text" name="sutradara" id="sutradara">
 				</td>
 			</tr>
 			<tr>
 				<td>
 					<label for="pemain">Pemain</label>
 				</td>
 				<td>
 					<input type="text" name="pemain" id="pemain">
 				</td>
 			</tr>
 			<tr>
 				<td>
 					<label for="jenis">Jenis Film</label>
 				</td>
 				<td>
 					<input type="text" name="jenis" id="jenis"><br>
 				</td>
 			</tr>
 			<tr>
 				<td>
 					<button type="submit" name="submit" id="submit">Tambah Data</button>
 				</td>
 			</tr>
  	</form>
 	</table>
 </body>
 </html>