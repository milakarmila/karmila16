<?php 

function koneksi(){
    $conn = mysqli_connect("localhost", "root", "") or die("koneksi ke DB gagal!");
    mysqli_select_db($conn, "tugas_pw_183040012") or die("Database salah!");
    return $conn;


}

function query($sql) {
    $conn = koneksi();
    $result = mysqli_query($conn, "$sql");

    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }


    return $rows;

}


function tambah($data)
{
        $conn = koneksi();

    $img = htmlspecialchars($data['img']);
    $judul = htmlspecialchars($data['judul']);
    $sutradara = htmlspecialchars($data['sutradara']);
    $pemain = htmlspecialchars($data['pemain']);
    $jenisfilm = htmlspecialchars($data['jenisfilm']);

    $query_tambah = "INSERT INTO film VALUES('','$img','$judul','$sutradara','$pemain','$jenisfilm')";

    mysqli_query($conn, $query_tambah);
    return mysqli_affected_rows($conn);
}

function hapus($no){

    $conn=koneksi();
    
    mysqli_query($conn, "DELETE FROM film WHERE no = $no");

    return mysqli_affected_rows($conn);
}
?>
