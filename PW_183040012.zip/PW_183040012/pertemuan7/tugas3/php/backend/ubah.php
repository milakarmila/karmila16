<?php 
require 'function.php';

$no = $_GET['no'];
$adm = query("SELECT * FROM film WHERE no = $no") [0];
if (isset($_POST['ubah'])){
    if (ubah($_POST) > 0) {
        echo "<script>
                alert('Data Berhasil Diubah');
                document.location.href = 'index.php';
                </script>";
    } else {

        echo "<script>
                alert('Data Gagal Diubah!');
                document.location.href = 'index.php';
                </script>";

    }
}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
    <title>Tambah Data Film</title>
 </head>
 <body>
    <form action="" method="post">

        <input type="hidden" name="id" value="<?= $adm['no']?>">

        <label for="img">Gambar</label>:
        <input type="text" name="img" id="img" value="<?= $adm['img']?>"><br>
        <label for="judul">Judul</label>:
        <input type="text" name="judul" id="judul" value="<?= $adm['judul']?>"><br>
        <label for="sutradara">sutradara</label>:
        <input type="text" name="sutradara" id="sutradara" value="<?= $adm['sutradara']?>"><br>
        <label for="pemain">pemain</label>:
        <input type="text" name="pemain" id="pemain" value="<?= $adm['pemain']?>"><br>
        <label for="jenis">Jenis Film</label>:
        <input type="text" name="jenis" id="jenis" value="<?= $adm['jenis']?>"><br>

        <button type="submit" name="ubah" id="submit">ubah data</button>
    
 </body>
 </html>