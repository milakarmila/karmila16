<?php 

require 'function.php';

// ambil data di url
$no = $_GET["no"];
 

// query data mahasiswa berdasarkan no
$adm = query("SELECT * FROM film WHERE no=$no")[0];

if (isset($_POST['submit'])){
    if (ubah($_POST) > 0) {
        echo "<script>
                alert('Data Berhasil Diubah');
                document.location.href = 'index.php';
                </script>";
    } else {

        echo "<script>
                alert('Data Gagal Diubah!');
                document.location.href = 'index.php';
                </script>";

    }
}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
    <title>Tambah Data Film</title>
    <style>
         .contener{
            background-color: Sandybrown ;
            width: 400px;
            height: 300px;
            margin: auto;
            font-family: cursive;
            font-size: 15px;
            padding: 10px; 
            box-shadow: 5px 5px 15px 5px #000000;
        }
        h2{
            text-align: center;
        }
    </style>
 </head>
 <body>
    <div class="contener">
        <h2>Edit film</h2>
    <table>
        <form action="" method="post">
            <tr>
                <td>
                    <label for="img">Gambar</label>
                </td>
                <td>
                    <input type="text" name="img" id="img" value="<?= $adm['img'];?>">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="judul">Judul</label>
                </td>
                <td>
                    <input type="text" name="judul" id="judul" value="<?= $adm['judul'];?>">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="sutradara">Sutradara</label>
                </td>
                <td>
                    <input type="text" name="sutradara" id="sutradara" value="<?= $adm['sutradara'];?>">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="pemain">Pemain</label>
                </td>
                <td>
                    <input type="text" name="pemain" id="pemain" value="<?= $adm['pemain'];?>">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="jenis">Jenis Film</label>
                </td>
                <td>
                    <input type="text" name="jenis" id="jenis" value="<?= $adm['jenis'];?>"><br>
                </td>
            </tr>
            <tr>
                <td>
                    <button type="submit" name="submit" id="submit">Ubah Data</button>
                </td>
            </tr>
            </form>
            </div>
 </body>
 </html>