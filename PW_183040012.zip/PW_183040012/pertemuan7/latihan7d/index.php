<?php 
require 'function.php';
$film = query("SELECT * FROM film");
//var_dump($film);

 ?>


 <!DOCTYPE html>
 <html>
 <head>
   <title>latihan7b</title>
         <style>
        body{
            background:orange;
             background:-webkit-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             background:-moz-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             background:-o-radial-gradient(center, circle, orange 5%, red 45%, black 100%);
             filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0, finishopacity=100, style=2);height:100px;
        }
        h2{
            text-align: center;
        }
        tr{
            text-align: center;
            height: 50px;
            color: white;

        }
        .dm{
            text-decoration: none;
            color: black;
        }
        .bt{ text-decoration: none;
            color: black;
        }

    </style>
    </head>
    <body>
    <div class="contener">
    <h2>Selamat Datang di Film terbaru<br>2019</h2>
    <center><button><a class="dm" href="tambah.php">Tambah Data</a></button></center>
    <table align="center" border="1" cellspacing="0">
        <thead>
            <tr>
                <th width="20">No</th>
                <th>Gambar</th>
                <th>Judul</th>
                <th width="300">Sutradara</th>
                <th>Pemain</th>
                <th width="150">jenis Film</th>
                <th width="150">Alat</th>
            </tr>
        </thead>
        <tbody>
            <?php $i=1; ?>
            <?php foreach ($film as $adm): ?>
                <tr>
                    <td><?= $i++; ?></td>
                    <td><img align ="center" src="../assets/img/<?=$adm['img']; ?>"></td>
                    <td><?= $adm['judul']; ?></td>
                    <td><?= $adm['sutradara']; ?> </td>
                    <td><?= $adm['pemain']; ?> </td>
                    <td><?= $adm['jenis']; ?></td> 

                    <td>
                        <button><a class="bt" href="hapus.php?no=<?=$adm['no'];?>">Hapus</a></button> | 
                        <button><a class="bt" href="ubah.php?no=<?=$adm['no'];?>">ubah</a></button>
                    </td>

                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
 </body>
 </html>