<?php 
require 'function.php';
$no = $_GET["no"];
$adm = query("SELECT * FROM film WHERE no = $no")[0];
if (isset($_POST['ubah'])){
    if (ubah($_POST) > 0) {
        echo "<script>
                alert('Data Berhasil Diubah');
                document.location.href = 'index.php';
                </script>";
    } else {

        echo "<script>
                alert('Data Gagal Diubah!');
                document.location.href = 'index.php';
                </script>";

    }
}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
    <title>Tambah Data Film</title>
 </head>
 <body>
    <form action="" method="post">
        <tr>
            <td>
         <input type="   hidden" name="id" value="<?= $adm['no']?>">
        </tr>
        </td>

            <tr>
                <td>
                    <label for="img">Gambar</label>
                </td>
                <td>
                    <input type="text" name="img" id="img" value="<?= $adm['img'];?>">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="judul">Judul</label>
                </td>
                <td>
                    <input type="text" name="judul" id="judul" value="<?= $adm['judul'];?>">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="sutradara">Sutradara</label>
                </td>
                <td>
                    <input type="text" name="sutradara" id="sutradara" value="<?= $adm['sutradara'];?>">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="pemain">Pemain</label>
                </td>
                <td>
                    <input type="text" name="pemain" id="pemain" value="<?= $adm['pemain'];?>">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="jenis">Jenis Film</label>
                </td>
                <td>
                    <input type="text" name="jenis" id="jenis" value="<?= $adm['jenis'];?>"><br>
                </td>
            </tr>   
        
        <button type="submit" name="ubah" id="submit">Tambah Data</button>
        
 
 </body>
 </html>